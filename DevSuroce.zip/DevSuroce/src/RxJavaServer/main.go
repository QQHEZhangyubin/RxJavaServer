package main

import (
	_ "RxJavaServer/routers"
	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}

