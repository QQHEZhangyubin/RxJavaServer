---
name: 短域名服务
sort: 2
---

# 短域名服务

这个例子演示了如何使用 beego 开发 API 应用. 他包含了两个 API 接口:

* /v1/shorten
* /v1/expand

[到 GitHub 上浏览代码](https://github.com/beego/samples/tree/master/shorturl)
