---
root: true
name: beego第三方库
sort: 7
---

随着beego 的发展, 基于beego 的第三方库也逐渐的增加,如果大家有基于beego 的库,欢迎递交你的地址

- [gorelic](https://github.com/yvasiyarov/beego_gorelic) 
- [支付宝SDK](https://github.com/ascoders/alipay) 
- [pongo2](https://github.com/oal/beego-pongo2) 
- [keenio](https://github.com/pabdavis/beego_keenio)
