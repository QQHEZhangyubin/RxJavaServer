# 使用実績

<table class="docker_use_cases_table table">
    <thead>
        <tr>
            <td>ユースケース</td>
            <td>例</td>
            <td>リンク</td>
        </tr>
    </thead>
    
    <tbody>
        <tr>
            <td>ドキュメントサーバ</td>
            <td>Go Walker - オンザフライでGoプロジェクトのAPIドキュメントを生成するWebサーバです。</td>
            <td><a target="_blank" href="http://gowalker.org">http://gowalker.org</a></td>
        </tr>

        <tr>
        	<td>APIサービス</td>
        	<td>Youdaoの360検索APIで、数千万のリクエストレベルです。</td>
        </tr>

        <tr>
        	<td></td>
        	<td>BmobモバイルクラウドAPIサービスで、毎日5000万人以上のリクエストです。</td>
        </tr>

        <tr>
        	<td></td>
        	<td>Weicoの3つのバックエンドAPIサービス。</td>
        </tr>

        <tr>
        	<td>ブログ</td>
        	<td>Sudo China - マルチユーザブログシステム</td>
        	<td><a target="_blank" href="http://www.sudochina.com">http://sudochina.com</a></td>
        </tr>

        <tr>
        	<td>コミュニティ</td>
        	<td>Very Hour - ソーシャルネットワーク</td>
        	<td><a target="_blank" href="http://www.veryhour.com">http://veryhour.com</a></td>
        </tr>

        <tr>
        	<td>エンタープライズWebサイト</td>
        	<td>I Beautys</td>
        	<td><a target="_blank" href="http://www.ibeautys.com/">http://ibeautys.com/</a></td>
        </tr>

        <tr>
        	<td></td>
        	<td>Interla</td>
        	<td><a target="_blank" href="http://interla.net">http://interla.net</a></td>
        </tr>
    </tbody>
</table
