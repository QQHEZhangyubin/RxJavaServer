# 開発チーム

### AstaXie

- チームの役割: beegoのファウンダー、主開発者です。
- ソーシャルネットワーク: [Sina Weibo](http://weibo.com/533452688) [GitHub](https://github.com/astaxie) [Twitter](https://twitter.com/astaxie) [Google+](https://plus.google.com/u/0/111292884696033638814)

### Slene

- チームの役割: ORMの主責任者、beegoサンプルと公式サイトのメンテナです。
- ソーシャルネットワーク: [Sina Weibo](http://weibo.com/slene) [GitHub](https://github.com/slene) [Twitter](https://twitter.com/slene)


### ClownFish

- チームの役割: beego adminマネジメントシステムの主責任です。
- ソーシャルネットワーク: [GitHub](https://github.com/osgochina)

### Lei Cao

- チームの役割: 英語ドキュメントとリソースのメインメンテナです。
- ソーシャルネットワーク: [GitHub](https://github.com/lei-cao
