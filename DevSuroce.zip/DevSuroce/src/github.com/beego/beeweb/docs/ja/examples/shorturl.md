---
name: URL短縮化
sort: 2
---

# URL短縮化APIサービス

このサンプルはbeegoによるAPIアプリケーションです。2つのAPI関数があります:

```
/v1/shorten
```
```
/v1/expand
```

[GitHub上でコードを見る](https://github.com/beego/samples/tree/master/shorturl)
