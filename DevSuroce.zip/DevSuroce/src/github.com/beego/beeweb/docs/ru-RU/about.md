# О BeeGo

[![Build Status](https://drone.io/github.com/astaxie/beego/status.png)](https://drone.io/github.com/astaxie/beego/latest) [![Go Walker](http://gowalker.org/api/v1/badge)](http://gowalker.org/github.com/astaxie/beego)

Это руководство документирует BeeGo App Framework.

### Новичок в BeeGo?

Читай о [Быстром старте](quickstart).

### Не можешь что-то найти?

Поищи в [списке рассылки (beego-framework@googlegroups.com)](https://groups.google.com/forum/#!forum/beego-framework).

### Нужна помощь?

Напиши email на [beego-framework@googlegroups.com](mailto:beego-framework@googlegroups.com).

### Нашел баг?

Открой [тикет на github](https://github.com/astaxie/beego/issues).

### Хочешь помочь проекту?

Форкни [документацию](https://github.com/beego/beedoc), улучши и сделай пулл-реквест.

### Ищешь исходный код сайта?

Посети [Beego Web](https://github.com/beego/beeweb).
