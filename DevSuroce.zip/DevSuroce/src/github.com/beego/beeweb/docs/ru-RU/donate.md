# Помоги BeeGo

<h4>
	<b><font color="red">
		<p>BeeGo фреймворк специально создан для быстрой разработки веб-приложений и защиты чести языка Go.
		Ваша поддержка очень ценится и многое значит для нас.</p>
		<p>Core-команда BeeGo работает над развитием BeeGo уже больше года. Мы много вложили, чтобы предоставить лучший фреймворк каждому. И если вы чувствуете, что Beego полезен для вас и вы хотите дружески поддержать наш проект, то мы будем благодарны ^_^</p>
	</font></b>
</h4>

<h4>
	<b>Пожертвовать через Paypal:</b>
	<p>
		<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="MR3MV8ZX9BWJ2">
<table>
<tr><td><input type="hidden" name="on0" value="support beego">помочь BeeGo</td></tr><tr><td><select name="os0">
	<option value="Option 1">Вариант 1 $10.00 USD</option>
	<option value="Option 2">Вариант 2 $20.00 USD</option>
	<option value="Option 3">Вариант 3 $50.00 USD</option>
	<option value="Option 4">Вариант 4 $100.00 USD</option>
	<option value="Option 5">Вариант 5 $200.00 USD</option>
	<option value="Option 6">Вариант 6 $500.00 USD</option>
	<option value="Option 7">Вариант 7 $1,000.00 USD</option>
</select> </td></tr>
</table>
<input type="hidden" name="currency_code" value="USD">
<input type="image" src="https://www.paypalobjects.com/en_US/C2/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
	</p>
</h4>

### Ваше пожертвование будет использовано для:

- Поддержки разработки BeeGo
- Поддержки развития коммьюнити
- Поддержки проведения лекций
- Улучшения серверов
- Награждения внешних участников проекта

### Список пожертвовавших (последние сверху)

| Дата       | Пожертвовал    | Сумма   | Комментарии               |
| ---------------- |:---------:| --------:| ----------------------- |
|  2014-Jan-24 | Bernard Lim     | $20.00   |          |
|  2013-Dec-23 | William Kennedy     | $100.00   |          |
