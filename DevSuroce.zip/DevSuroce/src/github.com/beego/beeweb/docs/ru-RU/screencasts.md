# Скринкасты

Учебный план:
https://github.com/beego/tutorial

1. Документация фреймворка BeeGo - 1 - Ввведение в BeeGo

	<iframe width="640" height="360" src="//www.youtube.com/embed/zvXDgfoUKFY" frameborder="0" allowfullscreen></iframe>
	
	презентация: [Introduction to beego](http://go-talks.appspot.com/github.com/beego/tutorial/en/1/why_beego.slide#1)

2. Документация фреймворка BeeGo - 2 - Роутер (часть 1 из 3)

	<iframe width="640" height="360" src="//www.youtube.com/embed/LvAFH-oLvqY" frameborder="0" allowfullscreen></iframe>
	
	презентация: [Router Processor function/method](http://go-talks.appspot.com/github.com/beego/tutorial/en/2/router.part1.slide)


3. Документация фреймворка BeeGo - 2 - Роутер URI паттерны (часть 2 из 3)

    <iframe width="640" height="360" src="//www.youtube.com/embed/81kxo6FcoOw" frameborder="0" allowfullscreen></iframe>
    
    презентация: [Router RUI Patterns](http://go-talks.appspot.com/github.com/beego/tutorial/en/2/router.part2.slide)


4. Документация фреймворка BeeGo - 2 - Роутер наймспейсы (часть 3 из 3)

    <iframe width="640" height="360" src="//www.youtube.com/embed/W9tBcTcXGeo" frameborder="0" allowfullscreen></iframe>
    
    презентация: [Router Namespace](http://go-talks.appspot.com/github.com/beego/tutorial/en/2/router.part3.slide)

5. Документация фреймворка BeeGo - 3 - Конфигурационные параметры

    <iframe width="640" height="360" src="//www.youtube.com/embed/F3tieL1lX1I" frameborder="0" allowfullscreen></iframe>
    
    презентация: [Configuration Parameters](http://go-talks.appspot.com/github.com/beego/tutorial/en/3/params.slide)

6. Документация фреймворка BeeGo - 4 - Создать веб API приложение
   Минута в Beego

    <iframe width="640" height="360" src="//www.youtube.com/embed/w7RziV_Sn-g" frameborder="0" allowfullscreen></iframe>
    
    блог: [Building Web API with Auto Generated API Document Support](http://beego.me/blog/beego_api)

