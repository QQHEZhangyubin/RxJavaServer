1. Названия файлов

- Controller_Main.md -> controller_main.md
- ControllerMain.md -> controller_main.md

2. Общие формы

Beego -> BeeGo
beego -> BeeGo
