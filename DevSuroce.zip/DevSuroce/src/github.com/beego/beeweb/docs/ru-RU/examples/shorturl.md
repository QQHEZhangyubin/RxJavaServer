---
name: Сервис коротких ссылок
sort: 2
---

# API сервиса сокращателя ссылок

Пример API приложения основанного на BeeGo. Оно имеет всего две API функции:

/v1/shorten
/v1/expand

[Посмотреть код на GitHub](https://github.com/beego/samples/tree/master/shorturl)
