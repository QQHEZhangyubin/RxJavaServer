---
name: URL Shortener
sort: 2
---

# URL Shortener API service

This sample is an API application based on Beego. It has two API endpoints:

/v1/shorten
/v1/expand

[Browse the code on GitHub](https://github.com/beego/samples/tree/master/shorturl)
