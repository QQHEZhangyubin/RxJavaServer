# Developer Team

### AstaXie

- Team role: founder of beego, primary developer.
- Social network: [Sina Weibo](http://weibo.com/533452688) [GitHub](https://github.com/astaxie) [Twitter](https://twitter.com/astaxie) [Google+](https://plus.google.com/u/0/111292884696033638814)

### Slene

- Team role: primarily responsible for ORM, maintainer of Beego samples and official site.
- Social network: [Sina Weibo](http://weibo.com/slene) [GitHub](https://github.com/slene) [Twitter](https://twitter.com/slene)


### ClownFish

- Team role: primarily responsible for Beego admin management system.
- Social network: [GitHub](https://github.com/osgochina)

### Lei Cao

- Team role: Main maintainer for the English Docs and resources.
- Social network: [GitHub](https://github.com/lei-cao)