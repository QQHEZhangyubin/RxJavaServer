# What is this?

An open source project for beego blog.

## How to contribute?

Fork, update and pull request. No matter big or small, you're welcome!

## How it works?

Beego Web server checks update of this project and generates pages automatically.

## Note

Due to markdown render, you have to use standard markdown syntax in order to have expect results.

## License

[Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.html).