# beego 常见问题列表

 这里是一个在使用 beego 过程中遇到的常见问题列表, 这些问题可能是因为 go 或者 beego 以及系统的 bug, 也有可能是因为不正确的使用. 希望大家贡献和维护这个列表.

所有问题和解决方法都放在 [stackoverflow](http://stackoverflow.com), 这里只做一个索引.

1. [Beego API document swagger returns 404, 访问 Beego API swagger 文档返回 404](https://stackoverflow.com/questions/25438971/beego-api-document-swagger-returns-404)