# beego FAQ list

 This is a FAQ list for using beego. These questions might be because of bugs of go, beego or even the systems. They are also might be because of use the beego in the wrong way. Please also post your questions.

All these questions and answers are in [stackoverflow](http://stackoverflow.com), here is just a index.

1. [Beego API document swagger returns 404](https://stackoverflow.com/questions/25438971/beego-api-document-swagger-returns-404)